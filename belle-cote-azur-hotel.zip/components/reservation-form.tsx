"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, CreditCard, Smartphone, Wallet } from "lucide-react"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { cn } from "@/lib/utils"

const rooms = [
  { id: "1", name: "Chambre Standard", price: 45000 },
  { id: "2", name: "Chambre Deluxe", price: 75000 },
  { id: "3", name: "Suite Présidentielle", price: 150000 },
]

const paymentMethods = [
  { id: "mobile-money", name: "Mobile Money", icon: Smartphone },
  { id: "paypal", name: "PayPal", icon: Wallet },
  { id: "card", name: "Carte Bancaire", icon: CreditCard },
]

export function ReservationForm() {
  const [checkIn, setCheckIn] = useState<Date>()
  const [checkOut, setCheckOut] = useState<Date>()
  const [selectedRoom, setSelectedRoom] = useState("")
  const [guests, setGuests] = useState("1")
  const [paymentMethod, setPaymentMethod] = useState("")
  const [step, setStep] = useState(1)

  const calculateTotal = () => {
    if (!checkIn || !checkOut || !selectedRoom) return 0
    const room = rooms.find((r) => r.id === selectedRoom)
    if (!room) return 0
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))
    return room.price * nights
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (step === 1) {
      setStep(2)
    } else {
      // Process payment
      alert("Réservation confirmée ! Vous recevrez un email de confirmation.")
    }
  }

  return (
    <div className="container mx-auto px-4 max-w-4xl">
      <div className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Réservez votre séjour</h1>
        <p className="text-lg text-muted-foreground">Complétez le formulaire pour réserver votre chambre</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{step === 1 ? "Détails de la réservation" : "Paiement"}</CardTitle>
          <CardDescription>{step === 1 ? "Étape 1 sur 2" : "Étape 2 sur 2"}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {step === 1 ? (
              <>
                {/* Room Selection */}
                <div className="space-y-2">
                  <Label htmlFor="room">Type de chambre</Label>
                  <Select value={selectedRoom} onValueChange={setSelectedRoom} required>
                    <SelectTrigger id="room">
                      <SelectValue placeholder="Sélectionnez une chambre" />
                    </SelectTrigger>
                    <SelectContent>
                      {rooms.map((room) => (
                        <SelectItem key={room.id} value={room.id}>
                          {room.name} - {room.price.toLocaleString()} FCFA/nuit
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Date Selection */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Date d'arrivée</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !checkIn && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {checkIn ? format(checkIn, "PPP", { locale: fr }) : "Sélectionner"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={checkIn}
                          onSelect={setCheckIn}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>Date de départ</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !checkOut && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {checkOut ? format(checkOut, "PPP", { locale: fr }) : "Sélectionner"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={checkOut}
                          onSelect={setCheckOut}
                          disabled={(date) => date < (checkIn || new Date())}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {/* Guests */}
                <div className="space-y-2">
                  <Label htmlFor="guests">Nombre de personnes</Label>
                  <Select value={guests} onValueChange={setGuests} required>
                    <SelectTrigger id="guests">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num} {num === 1 ? "personne" : "personnes"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Personal Info */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Prénom</Label>
                    <Input id="firstName" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Nom</Label>
                    <Input id="lastName" required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Téléphone</Label>
                  <Input id="phone" type="tel" required />
                </div>

                {/* Total */}
                {checkIn && checkOut && selectedRoom && (
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex justify-between items-center text-lg font-semibold">
                      <span>Total</span>
                      <span className="text-2xl text-primary">{calculateTotal().toLocaleString()} FCFA</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))} nuit(s)
                    </p>
                  </div>
                )}
              </>
            ) : (
              <>
                {/* Payment Method Selection */}
                <div className="space-y-4">
                  <Label>Méthode de paiement</Label>
                  <div className="grid gap-4">
                    {paymentMethods.map((method) => {
                      const Icon = method.icon
                      return (
                        <button
                          key={method.id}
                          type="button"
                          onClick={() => setPaymentMethod(method.id)}
                          className={cn(
                            "flex items-center gap-4 p-4 border rounded-lg hover:border-primary transition-colors",
                            paymentMethod === method.id && "border-primary bg-primary/5",
                          )}
                        >
                          <div
                            className={cn(
                              "w-12 h-12 rounded-full flex items-center justify-center",
                              paymentMethod === method.id ? "bg-primary text-primary-foreground" : "bg-muted",
                            )}
                          >
                            <Icon className="w-6 h-6" />
                          </div>
                          <span className="font-medium">{method.name}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Payment Details */}
                {paymentMethod === "mobile-money" && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="operator">Opérateur</Label>
                      <Select required>
                        <SelectTrigger id="operator">
                          <SelectValue placeholder="Sélectionnez votre opérateur" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="orange">Orange Money</SelectItem>
                          <SelectItem value="mtn">MTN Mobile Money</SelectItem>
                          <SelectItem value="moov">Moov Money</SelectItem>
                          <SelectItem value="wave">Wave</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mobileNumber">Numéro de téléphone</Label>
                      <Input id="mobileNumber" type="tel" placeholder="+225 XX XX XX XX XX" required />
                    </div>
                  </div>
                )}

                {paymentMethod === "card" && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">Numéro de carte</Label>
                      <Input id="cardNumber" placeholder="1234 5678 9012 3456" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="expiry">Date d'expiration</Label>
                        <Input id="expiry" placeholder="MM/AA" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cvv">CVV</Label>
                        <Input id="cvv" placeholder="123" required />
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === "paypal" && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="paypalEmail">Email PayPal</Label>
                      <Input id="paypalEmail" type="email" placeholder="votre@email.com" required />
                    </div>
                  </div>
                )}

                {/* Summary */}
                <div className="bg-muted p-6 rounded-lg space-y-3">
                  <h3 className="font-semibold text-lg">Récapitulatif</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Chambre</span>
                      <span>{rooms.find((r) => r.id === selectedRoom)?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Arrivée</span>
                      <span>{checkIn && format(checkIn, "PPP", { locale: fr })}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Départ</span>
                      <span>{checkOut && format(checkOut, "PPP", { locale: fr })}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Personnes</span>
                      <span>{guests}</span>
                    </div>
                  </div>
                  <div className="border-t pt-3 mt-3">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Total à payer</span>
                      <span className="text-2xl font-bold text-primary">{calculateTotal().toLocaleString()} FCFA</span>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Actions */}
            <div className="flex gap-4">
              {step === 2 && (
                <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                  Retour
                </Button>
              )}
              <Button
                type="submit"
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={step === 1 ? !checkIn || !checkOut || !selectedRoom : !paymentMethod}
              >
                {step === 1 ? "Continuer" : "Confirmer et payer"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
